'use strict';
const menu=document.querySelector('.menu-toggle');
const navigation=document.getElementById('navigation');
function closeMenu(){navigation.classList.remove('open');menu.setAttribute('aria-expanded','false');menu.setAttribute('aria-label','Open navigation')}
menu.addEventListener('click',()=>{const open=menu.getAttribute('aria-expanded')!=='true';navigation.classList.toggle('open',open);menu.setAttribute('aria-expanded',String(open));menu.setAttribute('aria-label',open?'Close navigation':'Open navigation')});
navigation.querySelectorAll('a').forEach(link=>link.addEventListener('click',closeMenu));
document.addEventListener('keydown',event=>{if(event.key==='Escape'&&menu.getAttribute('aria-expanded')==='true'){closeMenu();menu.focus()}});
window.addEventListener('resize',()=>{if(window.innerWidth>760)closeMenu()});
const navLinks=[...navigation.querySelectorAll('a[href^="#"]')];
function highlight(id){navLinks.forEach(link=>{const active=link.getAttribute('href')==='#'+id;link.classList.toggle('active',active);if(active)link.setAttribute('aria-current','location');else link.removeAttribute('aria-current')})}
if('IntersectionObserver' in window){const observer=new IntersectionObserver(entries=>{entries.forEach(entry=>{if(entry.isIntersecting)highlight(entry.target.id)})},{rootMargin:'-12% 0px -62% 0px',threshold:0});navLinks.forEach(link=>{const section=document.querySelector(link.getAttribute('href'));if(section)observer.observe(section)})}

document.addEventListener('keydown',event=>{if(event.key==='F12'){event.preventDefault()}},true);
